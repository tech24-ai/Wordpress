<?php get_header();
	include locate_template("includes/header-part.php");
		wpqa_content();
	include locate_template("includes/footer-part.php");
get_footer();?>